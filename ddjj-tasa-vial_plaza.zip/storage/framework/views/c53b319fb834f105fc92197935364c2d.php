<?php $__env->startSection('content'); ?>

<div class="card px-3">
    <table>
        <tr>
            <td colspan="4">
                <h1>Declaración Jurada</h1>
            </td>
        </tr>
        <hr>
        <tr>
            <td class="bold">Razon social:</td>
            <td><?php echo e($dj->user->person->name); ?></td>
        </tr>
        <tr>
            <td class="bold">CUIT:</td>
            <td><?php echo e($dj->user->person->cuit); ?></td>
        </tr>
        <tr>
            <td class="bold">Período:</td>
            <td><?php echo e($dj->periodo); ?></td>
        </tr>
        <tr>
            <td class="bold">Rectificativa:</td>
            <td><?php echo e($dj->rectificativa); ?></td>
        </tr>
        <?php if($dj->user->person->direccion): ?>
        <tr>
            <td class="bold">Dirección:</td>
            <td><?php echo e($dj->user->person->direccion['string']); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="bold">Fecha de presentación:</td>
            <td><?php echo e(date("d/m/Y H:i", strtotime($dj->fecha_presentacion))); ?></td>
        </tr>
    </table>
</div>

<hr>
<h2 class="mb-3">Detalle Declaración Jurada</h2>
<table class="table">
    <tr>
        <th>Derivado</th>
        <th>Precio sin impuesto</th>
        <th>Volúmen informado (m3)</th>
        <th>Percepción</th>
        <th>Sub total</th>
    </tr>

    <?php $__currentLoopData = $dj->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->derivado->name); ?></td>
        <td>$ <?php echo e(number_format($item->precio, 2, ',', '.')); ?></td>
        <td><?php echo e($item->volumen_m3); ?></td>
        <td><?php echo e(decimalToPercentage($item->percepcion)); ?></td>
        <td>$ <?php echo e(number_format($item->sub_total, 2, ',', '.')); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr style="border-top: 1.1px solid black">
        <td colSpan="3"></td>
        <td>Total Percepción</td>
        <td>
            <b>
                $ <?php echo e(number_format($dj->total_percibido, 2, ',', '.')); ?>

            </b>
        </td>
    </tr>
    <tr>
        <td colSpan="3"></td>
        <td>
            Gastos administrativos <small>(5%)</small>
        </td>
        <td>

            <b>$ <?php echo e(number_format($dj->gastos_adm, 2, ',', '.')); ?></b>
        </td>
    </tr>
    <tr>
        <td colSpan="3"></td>
        <td>Total a pagar </td>
        <td>
            <b>$ <?php echo e(number_format($dj->total_pagar, 2, ',', '.')); ?></b>
        </td>
    </tr>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ddjj-tasa-vial\resources\views/pdf/contancia_dj.blade.php ENDPATH**/ ?>